"""
    Base terminal command manager.

    Define terminal commands here to run actions
"""
from flask_script import Manager, Server
from flask_sqlalchemy import SQLAlchemy
from system.init import initialize_app

app = initialize_app()

manager = Manager(app)

app.secret_key = "80923yh8efd98f0h3hd"

manager.add_command('runserver', Server(host='127.0.0.1'))

if __name__ == "__main__":
    manager.run()
