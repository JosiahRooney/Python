"""
    Sample Controller File

    A Controller should be in charge of responding to a request.
    Load models to interact with the database and load views to render them to the client.

    Create a controller using this template
"""
from system.core.controller import *
import random
from datetime import datetime

class Welcome(Controller):
    def __init__(self, action):
        super(Welcome, self).__init__(action)
        """
        This is an example of loading a model.
        Every controller has access to the load_model method.
        """
        self.load_model('WelcomeModel')
        self.db = self._app.db

        """
        This is an example of a controller method that will load a view for the client
        """
   
    def index(self):
        """
        A loaded model is accessible through the models attribute 
        self.models['WelcomeModel'].get_users()
        
        self.models['WelcomeModel'].add_message()
        # messages = self.models['WelcomeModel'].grab_messages()
        # user = self.models['WelcomeModel'].get_user()
        # to pass information on to a view it's the same as it was with Flask
        
        # return self.load_view('index.html', messages=messages, user=user)
        """
        if 'gold' not in session:
            session['gold'] = 0

        if "results" not in session:
            session['results'] = []

        return self.load_view('index.html')

    def gold(self, building):
        message = {}
        message['date'] = datetime.now()
        if building == "farm":
            num = random.randrange(2,5)
            session['gold'] += num
            message['class'] = "gain"
            message['message'] = "You gained "+str(num)+" gold from the "+building
        elif building == "forest":
            num = random.randrange(5,10)
            session['gold'] += num
            message['class'] = "gain"
            message['message'] = "You gained "+str(num)+" gold from the "+building
        elif building == "cave":
            num = random.randrange(10,20)
            session['gold'] += num
            message['class'] = "gain"
            message['message'] = "You gained "+str(num)+" gold from the "+building
        elif building == "casino":
            if session['gold'] >= 50:
                num = random.randrange(-50, 50)
                session['gold'] += num
                if num > 0:
                    message['class'] = "gain"
                    message['message'] = "You gained "+str(num)+" gold from the "+building
                else:
                    message['class'] = "loss"
                    message['message'] = "You lost "+str(num)+" gold from the "+building
            else:
                flash('You don\'t have enough gold!', 'error')
                return redirect('/')
        else:
            flash('What the hell did you click to get here?!','error')
        session['results'] = [message] + session['results']
        return redirect('/')